package com.sports.tvremote;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.Closeable;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;

/** Android TV Remote Service v2 - pairing 6467, control 6466. */
public final class TvRemote implements Closeable {
    public interface Listener {
        void status(String value);
        void pairingCodeReady();
        void pairingSucceeded();
        void connected();
        void disconnected(String problem);
    }
    private final Context context;
    private final Listener listener;
    private final SharedPreferences settings;
    private final Object writeLock=new Object();
    private volatile SSLSocket control;
    private volatile SSLSocket pairing;
    private volatile java.io.OutputStream controlOut;
    private volatile boolean ready=false;
    private volatile String host;
    private volatile X509Certificate pairServerCert;
    private Identity identity;

    public TvRemote(Context context,Listener listener) {
        this.context=context.getApplicationContext();this.listener=listener;
        settings=context.getSharedPreferences("settings",Context.MODE_PRIVATE);
    }
    public boolean isReady(){return ready;}

    private static class CapturingTrust implements X509TrustManager {
        volatile X509Certificate peer;
        @Override public void checkClientTrusted(X509Certificate[] c,String a) { }
        @Override public void checkServerTrusted(X509Certificate[] c,String a) {if(c!=null&&c.length>0)peer=c[0];}
        @Override public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
    }
    private static class Tls {
        final SSLSocket socket;
        final X509Certificate peer;
        Tls(SSLSocket s,X509Certificate p){socket=s;peer=p;}
    }
    private Tls connectTls(String ip,int port,boolean checkPinned) throws Exception {
        if(identity==null)identity=Identity.load(context);
        KeyManagerFactory km=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        km.init(identity.store,Identity.password());
        CapturingTrust trust=new CapturingTrust();
        SSLContext ctx=SSLContext.getInstance("TLS");
        ctx.init(km.getKeyManagers(),new javax.net.ssl.TrustManager[]{trust},new SecureRandom());
        SSLSocket socket=(SSLSocket)ctx.getSocketFactory().createSocket();
        try {
            socket.connect(new InetSocketAddress(ip,port),6000);
            socket.setSoTimeout(12000);
            socket.startHandshake();
            X509Certificate cert=trust.peer;
            if(cert==null)cert=(X509Certificate)socket.getSession().getPeerCertificates()[0];
            // Cert verification on first pairing happens via the on-screen PIN digest.
            // Pin the TV certificate for subsequent remote sessions.
            if(checkPinned) {
                String pinned=settings.getString("pin:"+ip,"");
                if(!pinned.isEmpty() && !pinned.equals(sha256(cert.getEncoded()))) {
                    throw new IOException("电视身份发生变化，请重新配对");
                }
            }
            return new Tls(socket,cert);
        }catch(Exception e){try{socket.close();}catch(Exception ignored){}throw e;}
    }
    private static String sha256(byte[] b) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(b);
        StringBuilder s=new StringBuilder();for(byte x:digest)s.append(String.format(java.util.Locale.US,"%02x",x&255));return s.toString();
    }
    private static byte[] raw(BigInteger number) {
        byte[] b=number.toByteArray();
        return b.length>1&&b[0]==0?Arrays.copyOfRange(b,1,b.length):b;
    }
    private static Proto.Writer packet(int field,Proto.Writer body) {
        return new Proto.Writer().num(1,2).num(2,200).child(field,body);
    }
    private static void statusOk(Proto.Fields fields) throws IOException {
        long status=fields.num(2);
        if(fields.has(2)&&status!=200)throw new IOException("配对被电视拒绝，状态码 "+status);
    }
    private static void send(SSLSocket socket,Proto.Writer body) throws IOException {Proto.write(socket.getOutputStream(),body.build());}

    /** Called on a worker thread, returns when the TV is displaying a six-digit hex PIN. */
    public void startPair(String ip) throws Exception {
        closePair();host=ip;
        listener.status("正在连接电视配对服务…");
        Tls tls=connectTls(ip,6467,false);pairing=tls.socket;pairServerCert=tls.peer;
        send(pairing,packet(10,new Proto.Writer().string(1,"atvremote").string(2,"TedeAr Sports Remote")));
        boolean configured=false;
        for(int i=0;i<8;i++) {
            Proto.Fields incoming=Proto.parse(Proto.read(pairing.getInputStream()));statusOk(incoming);
            if(incoming.has(11)) {
                Proto.Writer encoding=new Proto.Writer().num(1,3).num(2,6);
                send(pairing,packet(20,new Proto.Writer().child(1,encoding).num(3,1)));
            } else if(incoming.has(20)) {
                Proto.Writer encoding=new Proto.Writer().num(1,3).num(2,6);
                send(pairing,packet(30,new Proto.Writer().child(1,encoding).num(2,1)));
            } else if(incoming.has(31)) {configured=true;break;}
            else if(incoming.has(30)) {continue;}
        }
        if(!configured)throw new IOException("配对协商未完成");
        pairing.setSoTimeout(120000);
        listener.pairingCodeReady();
    }
    /** Called on a worker thread after the user enters the TV's displayed PIN. */
    public void completePair(String userCode) throws Exception {
        if(pairing==null||pairServerCert==null)throw new IOException("请先点击开始配对");
        String code=userCode.trim().toUpperCase(java.util.Locale.US);
        if(!code.matches("[0-9A-F]{6}"))throw new IOException("请输入电视显示的6位十六进制配对码");
        RSAPublicKey client=(RSAPublicKey)identity.certificate.getPublicKey();
        RSAPublicKey server=(RSAPublicKey)pairServerCert.getPublicKey();
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        md.update(raw(client.getModulus()));md.update(raw(client.getPublicExponent()));
        md.update(raw(server.getModulus()));md.update(raw(server.getPublicExponent()));
        md.update((byte)Integer.parseInt(code.substring(2,4),16));
        md.update((byte)Integer.parseInt(code.substring(4,6),16));
        byte[] digest=md.digest();
        if((digest[0]&255)!=Integer.parseInt(code.substring(0,2),16)) {
            throw new IOException("配对码校验不正确，请检查电视显示的数字");
        }
        try {
            send(pairing,packet(40,new Proto.Writer().bytes(1,digest)));
            Proto.Fields incoming=Proto.parse(Proto.read(pairing.getInputStream()));statusOk(incoming);
            if(!incoming.has(41))throw new IOException("电视没有确认配对");
            settings.edit().putString("pin:"+host,sha256(pairServerCert.getEncoded()))
                .putString("lastIp",host).apply();
            listener.pairingSucceeded();
        } finally{closePair();}
    }
    public void openRemote(String ip) throws Exception {
        closeControl();host=ip;ready=false;
        listener.status("正在连接 Google TV 遥控服务…");
        Tls tls=connectTls(ip,6466,true);
        control=tls.socket;controlOut=control.getOutputStream();
        boolean activated=false;
        for(int i=0;i<20;i++) {
            Proto.Fields incoming=Proto.parse(Proto.read(control.getInputStream()));
            handle(incoming);
            if(incoming.has(40)){activated=true;break;}
        }
        if(!activated)throw new IOException("电视未启动遥控会话");
        control.setSoTimeout(0);ready=true;
        listener.connected();
        final SSLSocket session=control;
        Thread reader=new Thread(()->{
            try {
                while(session==control && !session.isClosed())
                    handle(Proto.parse(Proto.read(session.getInputStream())));
            } catch(Exception problem) {
                if(session==control && ready){ready=false;listener.disconnected("电视连接已断开："+problem.getMessage());}
            }
        },"google-tv-reader");
        reader.setDaemon(true);reader.start();
    }
    private void handle(Proto.Fields fields) throws IOException {
        if(fields.has(1)) {
            long features=1|2|32|64|512;
            Proto.Writer info=new Proto.Writer().num(3,1).string(4,"1").string(5,"TedeAr Sports Remote").string(6,"1.0");
            sendControl(new Proto.Writer().child(1,new Proto.Writer().num(1,features).child(2,info)));
        }
        if(fields.has(2))sendControl(new Proto.Writer().child(2,new Proto.Writer().num(1,1|2|32|64|512)));
        if(fields.has(8))sendControl(new Proto.Writer().child(9,new Proto.Writer().num(1,fields.child(8).num(1))));
    }
    private void sendControl(Proto.Writer writer) throws IOException {
        synchronized(writeLock){if(controlOut==null)throw new IOException("尚未连接 Google TV");Proto.write(controlOut,writer.build());}
    }
    public void press(int key) throws IOException {
        if(!ready)throw new IOException("尚未连接 Google TV");
        sendControl(new Proto.Writer().child(10,new Proto.Writer().num(1,key).num(2,3)));
    }
    public void launch(String url) throws IOException {
        if(!ready)throw new IOException("尚未连接 Google TV");
        sendControl(new Proto.Writer().child(90,new Proto.Writer().string(1,url)));
    }
    public void closePair(){
        if(pairing!=null)try{pairing.close();}catch(Exception ignored){}
        pairing=null;pairServerCert=null;
    }
    public void closeControl(){
        ready=false;
        SSLSocket previous=control;control=null;controlOut=null;
        if(previous!=null)try{previous.close();}catch(Exception ignored){}
    }
    @Override public void close(){closePair();closeControl();}
}
