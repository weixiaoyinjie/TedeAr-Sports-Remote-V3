package com.sports.tvremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone-only sports TV remote: local protocol and user-recorded navigation macros. */
public class MainActivity extends Activity implements TvRemote.Listener {
    private static final int BG=Color.rgb(10,20,34), PANEL=Color.rgb(27,44,66);
    private static final int TILE=Color.rgb(33,54,78), ORANGE=Color.rgb(255,137,55);
    private static final int WHITE=Color.WHITE, SUB=Color.rgb(189,202,218);
    // 56 distinct sports channels explicitly visible in the user's supplied screenshots.
    // Keep the original six seed IDs to preserve recorded macros in V1/V2.
    private static final String[] LEGACY_CHANNELS={"Deporte 1","Deporte 2","Deporte 3", "ESPN Premium","ESPN Premium OP2","TNT Sports"};
    private static final String[] DEFAULT_MAS={"deporte 1", "deporte 2", "deporte 3"};
    private static final String[] DEFAULT_DEPORTES={"ESPN PREMIUM", "ESPN PREMIUM OP2", "TNT SPORTS", "AMERICA SPORTS", "BEIN SPORTS XTRA", "BEIN SPORTS XTRA Ñ", "DAZN COMBAT", "DAZN F1 OP1", "DAZN F1 OP2", "DEPORTV", "ESPN", "ESPN 2", "ESPN 3", "ESPN 4", "ESPN 5", "ESPN 6", "ESPN 7", "EVENTOS EXCLUSIVOS 116", "EVENTOS EXCLUSIVOS 117", "FOX SPORTS HD", "FOX SPORTS 2 HD", "FOX SPORTS 3 HD", "FOX SPORTS PREMIUM", "GARAGE TV", "GOLF CHANNEL", "Identidad 1", "IDENTIDAD 4", "san martin-cipoletti", "LPFPLAY", "LPFPLAY 2", "LPFPLAY 3", "LPFPLAY 4", "LPFPLAY 5", "LPFPLAY 6", "LPFPLAY 7", "LPFPLAY 8", "LPFPLAY 9", "LPFPLAY 10", "LPFPLAY 11", "LPFPLAY 12", "LPFPLAY 13", "LPFPLAY 14", "LPFPLAY 15", "NBA", "PX SPORTS", "Rally TV", "REAL MADRID TV", "Red Bull TV", "SHOWSPORT", "SKY DAZN F1", "TUDN", "TYC INTERNACIONAL", "TYC SPORTS"};
    private static final String GROUP_DEPORTES="DEPORTES";
    private static final String GROUP_MAS="MAS DEPORTES Y ALGO MAS";
    private static final String CATALOG_KEY="channelCatalogV2";
    private static final int MAX_CHANNELS=500;
    private static final class Channel {
        String id, name, group;
        boolean favorite;
        Channel(String id,String name,String group,boolean favorite){
            this.id=id;this.name=name;this.group=group;this.favorite=favorite;
        }
    }
    private static final String PKG="com.tedear.app";

    private TvRemote remote;
    private SharedPreferences prefs;
    private final ExecutorService work=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private EditText ipField, pinField;
    private TextView statusLabel, recordLabel;
    private final ArrayList<Channel> catalog=new ArrayList<>();
    private LinearLayout channelGrid;
    private TextView channelCount;
    private EditText channelSearch;
    private String channelFilter="all";
    private LinearLayout recordArea;
    private Channel recording=null;
    private JSONArray recorded=new JSONArray();
    private boolean playing=false;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicastLock;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("settings",MODE_PRIVATE);
        remote=new TvRemote(this,this);
        loadChannels();
        buildUi();
        if(!prefs.getString("lastIp","").isEmpty())main.postDelayed(this::connectTv,300);
    }

    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private GradientDrawable surface(int color,int radius,int strokeColor) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(strokeColor!=0)d.setStroke(dp(1),strokeColor);return d;
    }
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    private void add(LinearLayout parent,View child,int h){parent.addView(child,new LinearLayout.LayoutParams(-1,h==-1?-1:dp(h)));}
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private Button button(String value,int bg,boolean strong){
        Button b=new Button(this);b.setAllCaps(false);b.setText(value);b.setTextSize(strong?16:14);
        b.setTextColor(WHITE);b.setTypeface(Typeface.DEFAULT,strong?Typeface.BOLD:Typeface.NORMAL);
        b.setBackground(surface(bg,13,0));b.setMinimumHeight(0);b.setMinHeight(0);
        pad(b,6,8,6,8);return b;
    }
    private void addGap(LinearLayout p,int h){View gap=new View(this);p.addView(gap,new LinearLayout.LayoutParams(1,dp(h)));}
    private void two(LinearLayout parent,View a,View b,int height){
        LinearLayout line=horizontal();
        LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,dp(height),1f);
        LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,dp(height),1f);
        right.leftMargin=dp(8);
        line.addView(a,left);line.addView(b,right);add(parent,line,height);
    }
    private LinearLayout card(LinearLayout root){
        LinearLayout panel=vertical();panel.setBackground(surface(PANEL,18,Color.rgb(53,76,106)));
        pad(panel,15,15,15,15);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(16);
        root.addView(panel,lp);return panel;
    }
    private EditText input(String hint,String value){
        EditText box=new EditText(this);box.setSingleLine(true);box.setText(value);
        box.setHint(hint);box.setTextSize(15);box.setTextColor(WHITE);box.setHintTextColor(SUB);
        box.setBackground(surface(Color.rgb(15,30,46),10,Color.rgb(65,84,107)));
        pad(box,13,12,13,12);return box;
    }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=vertical();pad(root,16,19,16,30);scroll.addView(root);setContentView(scroll);
        TextView title=text("TedeAr  全体育遥控器 V3",24,WHITE,true);add(root,title,40);
        TextView sub=text("只看体育 · 手机控制 Google TV",13,SUB,false);add(root,sub,29);

        LinearLayout connection=card(root);
        TextView connTitle=text("① 连接 Google TV",17,WHITE,true);add(connection,connTitle,31);
        statusLabel=text("未连接电视",13,SUB,false);add(connection,statusLabel,27);
        ipField=input("Google TV IP，例如 192.168.1.50",prefs.getString("lastIp",""));
        ipField.setInputType(InputType.TYPE_CLASS_TEXT);add(connection,ipField,51);addGap(connection,9);
        Button scan=button("搜索电视",TILE,false), connect=button("连接电视",ORANGE,true);
        two(connection,scan,connect,48);scan.setOnClickListener(v->scanTv());connect.setOnClickListener(v->connectTv());
        addGap(connection,10);
        Button startPair=button("首次使用：开始配对",TILE,false);
        add(connection,startPair,43);startPair.setOnClickListener(v->pairTv());addGap(connection,8);
        pinField=input("电视显示的六位配对码","");
        pinField.setFilters(new InputFilter[]{new InputFilter.AllCaps(),new InputFilter.LengthFilter(6)});
        pinField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        Button finishPair=button("确认配对码",TILE,false);
        two(connection,pinField,finishPair,46);finishPair.setOnClickListener(v->finishPairTv());
        TextView note=text("配对需要打开电视画面。手机与电视必须在同一个局域网。",12,SUB,false);
        addGap(connection,8);add(connection,note,42);

        LinearLayout channels=card(root);
        TextView channelsTitle=text("② 全部体育频道",19,WHITE,true);add(channels,channelsTitle,33);
        Button open=button("▶  打开电视上的 TedeAr",ORANGE,true);
        add(channels,open,54);open.setOnClickListener(v->openTedeAr());
        open.setOnLongClickListener(v->{chooseLaunchMode();return true;});
        addGap(channels,10);
        channelCount=text("",12,SUB,false);add(channels,channelCount,45);
        channelSearch=input("搜索体育频道名称（ESPN、TNT、Deporte…）","");
        add(channels,channelSearch,50);addGap(channels,8);
        channelSearch.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){refreshChannelButtons();}
            @Override public void afterTextChanged(Editable e){}
        });
        Button all=button("全部",ORANGE,true), fav=button("★ 收藏",TILE,false),ready=button("已录制",TILE,false);
        LinearLayout filters=horizontal();
        addWeighted(filters,all,1);addWeighted(filters,fav,1);addWeighted(filters,ready,1);
        add(channels,filters,44);addGap(channels,8);
        all.setOnClickListener(v->{channelFilter="all";all.setBackground(surface(ORANGE,13,0));fav.setBackground(surface(TILE,13,0));ready.setBackground(surface(TILE,13,0));refreshChannelButtons();});
        fav.setOnClickListener(v->{channelFilter="favorite";fav.setBackground(surface(ORANGE,13,0));all.setBackground(surface(TILE,13,0));ready.setBackground(surface(TILE,13,0));refreshChannelButtons();});
        ready.setOnClickListener(v->{channelFilter="ready";ready.setBackground(surface(ORANGE,13,0));all.setBackground(surface(TILE,13,0));fav.setBackground(surface(TILE,13,0));refreshChannelButtons();});
        Button addChannel=button("+ 添加体育频道",TILE,false),importMany=button("批量导入频道名单",TILE,false);
        two(channels,addChannel,importMany,48);addGap(channels,9);
        addChannel.setOnClickListener(v->addChannelDialog());importMany.setOnClickListener(v->importChannelsDialog());
        TextView hint=text("已收录截图中确认的56个体育频道。点击已录制频道可切台；长按频道可录制、收藏、改名、删除。",12,SUB,false);
        add(channels,hint,67);
        channelGrid=vertical();channels.addView(channelGrid,new LinearLayout.LayoutParams(-1,-2));
        refreshChannelButtons();

        recordArea=card(root);
        recordLabel=text("③ 录制频道步骤（首次设置）",17,WHITE,true);
        add(recordArea,recordLabel,34);
        TextView howto=text("长按任意体育频道 → 录制 → 使用下方遥控键操作到该频道 → 保存。每个频道的路径分别记录。",13,SUB,false);
        add(recordArea,howto,76);addGap(recordArea,8);
        Button wait2=button("+ 等待2秒",TILE,false),wait5=button("+ 等待5秒",TILE,false);
        two(recordArea,wait2,wait5,43);
        wait2.setOnClickListener(v->insertWait(2000));wait5.setOnClickListener(v->insertWait(5000));
        addGap(recordArea,8);
        Button save=button("保存录制",ORANGE,true),cancel=button("取消录制",TILE,false);
        two(recordArea,save,cancel,47);save.setOnClickListener(v->saveRecording());cancel.setOnClickListener(v->cancelRecording());
        recordArea.setVisibility(View.GONE);

        LinearLayout keys=card(root);
        TextView keysTitle=text("④ 电视遥控按键",17,WHITE,true);add(keys,keysTitle,38);
        LinearLayout row=horizontal();
        Button up=button("▲",TILE,true);keyButton(up,19);
        addWeighted(row,new View(this),1);addWeighted(row,up,1);addWeighted(row,new View(this),1);
        add(keys,row,49);addGap(keys,6);
        row=horizontal();Button left=button("◀",TILE,true),ok=button("OK",ORANGE,true),right=button("▶",TILE,true);
        keyButton(left,21);keyButton(ok,23);keyButton(right,22);
        addWeighted(row,left,1);addWeighted(row,ok,1);addWeighted(row,right,1);add(keys,row,49);addGap(keys,6);
        row=horizontal();Button down=button("▼",TILE,true);keyButton(down,20);
        addWeighted(row,new View(this),1);addWeighted(row,down,1);addWeighted(row,new View(this),1);add(keys,row,49);addGap(keys,12);
        Button back=button("返回",TILE,false),home=button("主页",TILE,false);
        keyButton(back,4);keyButton(home,3);two(keys,back,home,46);addGap(keys,8);
        Button volMinus=button("音量 −",TILE,false),mute=button("静音",TILE,false),volPlus=button("音量 +",TILE,false);
        keyButton(volMinus,25);keyButton(mute,164);keyButton(volPlus,24);
        row=horizontal();addWeighted(row,volMinus,1);addWeighted(row,mute,1);addWeighted(row,volPlus,1);add(keys,row,46);
        addGap(keys,8);Button menu=button("菜单",TILE,false),play=button("播放 / 暂停",TILE,false);
        keyButton(menu,82);keyButton(play,85);two(keys,menu,play,46);

        TextView footer=text("仅控制你自己已安装的 TedeAr；不提供视频源。频道直达需预先录制，播放效果以电视实际响应为准。",12,SUB,false);
        add(root,footer,60);
    }
    private void addWeighted(LinearLayout row,View v,float weight){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,weight);
        lp.leftMargin=dp(3);lp.rightMargin=dp(3);row.addView(v,lp);
    }
    private String ip(){return ipField.getText().toString().trim();}
    private void show(String value){main.post(()->{statusLabel.setText(value);});}
    private void toast(String value){main.post(()->Toast.makeText(this,value,Toast.LENGTH_LONG).show());}
    private void error(Exception e){show("⚠ "+e.getMessage());toast(e.getMessage()==null?"操作失败":e.getMessage());}
    private boolean requireConnected(){if(!remote.isReady()){toast("请先连接 Google TV");return false;}return true;}

    private void connectTv(){
        String host=ip();if(host.isEmpty()){toast("请填写或搜索电视 IP");return;}
        prefs.edit().putString("lastIp",host).apply();
        work.execute(()->{
            try{remote.openRemote(host);}catch(Exception e){remote.closeControl();error(e);}
        });
    }
    private void pairTv(){
        String host=ip();if(host.isEmpty()){toast("先输入电视 IP 或点击搜索电视");return;}
        prefs.edit().putString("lastIp",host).apply();
        work.execute(()->{
            try{remote.startPair(host);}catch(Exception e){remote.closePair();error(e);}
        });
    }
    private void finishPairTv(){
        String code=pinField.getText().toString().trim();
        if(code.length()!=6){toast("请填写电视上的六位配对码");return;}
        work.execute(()->{
            try{
                remote.completePair(code);
                remote.openRemote(ip());
            }catch(Exception e){error(e);}
        });
    }

    private void scanTv(){
        if(discovery!=null){toast("正在搜索电视…");return;}
        show("正在搜索局域网中的 Google TV…");
        try{
            WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if(wifi!=null){multicastLock=wifi.createMulticastLock("TedeArTVScan");multicastLock.setReferenceCounted(false);multicastLock.acquire();}
            nsd=(NsdManager)getSystemService(Context.NSD_SERVICE);
            discovery=new NsdManager.DiscoveryListener(){
                @Override public void onDiscoveryStarted(String type){}
                @Override public void onServiceFound(NsdServiceInfo info){
                    try{nsd.resolveService(info,new NsdManager.ResolveListener(){
                        @Override public void onResolveFailed(NsdServiceInfo service,int code){}
                        @Override public void onServiceResolved(NsdServiceInfo service){
                            InetAddress host=service.getHost();
                            if(host!=null && host.getHostAddress()!=null){
                                main.post(()->{ipField.setText(host.getHostAddress());show("找到电视："+service.getServiceName()+" · "+host.getHostAddress());stopDiscovery();});
                            }
                        }
                    });}catch(Exception ignored){}
                }
                @Override public void onServiceLost(NsdServiceInfo info){}
                @Override public void onDiscoveryStopped(String type){}
                @Override public void onStartDiscoveryFailed(String type,int code){main.post(()->{show("自动搜索失败，请手动填写 IP");stopDiscovery();});}
                @Override public void onStopDiscoveryFailed(String type,int code){main.post(()->stopDiscovery());}
            };
            nsd.discoverServices("_androidtvremote2._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
            main.postDelayed(()->{if(discovery!=null){stopDiscovery();show("搜索结束。若未发现电视，可手动输入其 IP 地址。");}},12000);
        }catch(Exception e){stopDiscovery();error(e);}
    }
    private void stopDiscovery(){
        NsdManager.DiscoveryListener old=discovery;discovery=null;
        if(nsd!=null && old!=null)try{nsd.stopServiceDiscovery(old);}catch(Exception ignored){}
        if(multicastLock!=null){try{if(multicastLock.isHeld())multicastLock.release();}catch(Exception ignored){}multicastLock=null;}
    }

    private String launchUri(){
        if(prefs.getBoolean("useMarketLink",false))return "market://launch?id="+PKG;
        return "android-app://"+PKG;
    }
    private void chooseLaunchMode(){
        String[] names={"Android App 启动链接（默认）","Google TV 市场启动链接（备用）"};
        new AlertDialog.Builder(this).setTitle("TedeAr 启动方式")
            .setSingleChoiceItems(names,prefs.getBoolean("useMarketLink",false)?1:0,(dialog,which)->{
                prefs.edit().putBoolean("useMarketLink",which==1).apply();dialog.dismiss();
                toast("已切换启动方式。可以重新尝试打开 TedeAr。");
            }).setNegativeButton("取消",null).show();
    }
    private void openTedeAr(){
        if(!requireConnected())return;
        String uri=launchUri();recordStep("app",uri);
        work.execute(()->{
            try{remote.launch(uri);show("已发送 TedeAr 启动请求（电视是否打开需现场确认）");}
            catch(Exception e){error(e);}
        });
    }
    private void keyButton(Button b,int key){b.setOnClickListener(v->sendKey(key));}
    private void sendKey(int key){
        if(!requireConnected())return;
        recordStep("key",key);
        work.execute(()->{try{remote.press(key);}catch(Exception e){error(e);}});
    }
    private JSONArray macroFor(Channel channel){
        String raw=prefs.getString("macro:"+channel.id,"");
        try{return new JSONArray(raw);}catch(Exception e){return new JSONArray();}
    }
    private void loadChannels(){
        String raw=prefs.getString(CATALOG_KEY,"");
        if(!raw.isEmpty()){
            try{
                JSONArray entries=new JSONArray(raw);
                for(int i=0;i<entries.length()&&catalog.size()<MAX_CHANNELS;i++){
                    JSONObject o=entries.optJSONObject(i);
                    if(o==null)continue;
                    String name=o.optString("name","").trim();
                    String id=o.optString("id","").trim();
                    if(name.isEmpty()||id.isEmpty()||hasChannel(name))continue;
                    String group=GROUP_MAS.equals(o.optString("group"))?GROUP_MAS:GROUP_DEPORTES;
                    catalog.add(new Channel(id,name,group,o.optBoolean("favorite",false)));
                }
            }catch(Exception ignored){catalog.clear();}
        }
        // First installation: keep original channel IDs so old six macros can be reused.
        if(catalog.isEmpty()){
            for(int i=0;i<LEGACY_CHANNELS.length;i++){
                Channel c=new Channel("seed"+i,LEGACY_CHANNELS[i],i<3?GROUP_MAS:GROUP_DEPORTES,false);
                catalog.add(c);
                String old=prefs.getString("macro:"+i,"");
                if(!old.isEmpty()&&!prefs.contains("macro:"+c.id))prefs.edit().putString("macro:"+c.id,old).apply();
            }
        }
        // V3: append every sports channel seen in screenshots, without overwriting
        // previously imported channels, favorites, or their recorded macros.
        for(String name:DEFAULT_MAS)ensureBundledChannel(name,GROUP_MAS);
        for(String name:DEFAULT_DEPORTES)ensureBundledChannel(name,GROUP_DEPORTES);
        saveChannels();
    }
    private void ensureBundledChannel(String name,String group){
        if(!hasChannel(name)&&catalog.size()<MAX_CHANNELS)
            catalog.add(new Channel(UUID.randomUUID().toString(),name,group,false));
    }
    private void saveChannels(){
        JSONArray data=new JSONArray();
        try{
            for(Channel c:catalog)data.put(new JSONObject().put("id",c.id).put("name",c.name)
                .put("group",c.group).put("favorite",c.favorite));
            prefs.edit().putString(CATALOG_KEY,data.toString()).apply();
        }catch(Exception e){toast("频道名单保存失败："+e.getMessage());}
    }
    private boolean hasChannel(String name){
        for(Channel c:catalog)if(c.name.equalsIgnoreCase(name.trim()))return true;
        return false;
    }
    private boolean addChannel(String name,String group){
        name=name.trim();
        if(name.isEmpty()||name.length()>100||hasChannel(name)||catalog.size()>=MAX_CHANNELS)return false;
        catalog.add(new Channel(UUID.randomUUID().toString(),name,group,false));
        return true;
    }
    private void addChannelDialog(){
        EditText field=input("电视上显示的体育频道名称","");
        new AlertDialog.Builder(this).setTitle("添加体育频道").setView(field)
            .setPositiveButton("添加到 DEPORTES",(d,w)->addSingleChannel(field.getText().toString(),GROUP_DEPORTES))
            .setNeutralButton("添加到 MAS DEPORTES",(d,w)->addSingleChannel(field.getText().toString(),GROUP_MAS))
            .setNegativeButton("取消",null).show();
    }
    private void addSingleChannel(String name,String group){
        if(!addChannel(name,group)){toast("频道名称为空、重复、过长或数量已达上限");return;}
        saveChannels();refreshChannelButtons();
    }
    private void importChannelsDialog(){
        EditText field=new EditText(this);field.setTextSize(15);field.setTextColor(WHITE);
        field.setHintTextColor(SUB);field.setHint("每行一个频道；也可写 DEPORTES|频道名称 或 MAS DEPORTES|频道名称");
        field.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        field.setMinLines(6);field.setMaxLines(12);pad(field,15,10,15,10);
        ScrollView wrap=new ScrollView(this);wrap.addView(field);
        new AlertDialog.Builder(this).setTitle("批量导入全部体育频道")
            .setMessage("从电视上看到频道名称后，每行粘贴一个。不会清除原有频道或录制。")
            .setView(wrap)
            .setPositiveButton("导入",(d,w)->{
                int n=0;String[] lines=field.getText().toString().split("\\r?\\n");
                for(String line:lines){
                    String group=GROUP_DEPORTES,name=line.trim();
                    int index=name.indexOf('|');
                    if(index>=0){
                        String g=name.substring(0,index).trim().toUpperCase(Locale.ROOT);
                        group=g.contains("MAS")?GROUP_MAS:GROUP_DEPORTES;
                        name=name.substring(index+1).trim();
                    }
                    if(addChannel(name,group))n++;
                }
                saveChannels();refreshChannelButtons();toast("成功加入 "+n+" 个新体育频道");
            }).setNegativeButton("取消",null).show();
    }
    private void refreshChannelButtons(){
        if(channelGrid==null||channelCount==null||channelSearch==null)return;
        int configured=0;for(Channel c:catalog)if(macroFor(c).length()>0)configured++;
        channelCount.setText("频道库 "+catalog.size()+" 个 · 已录制 "+configured+" 个。已预置截图确认的56个体育频道，可继续添加和批量导入。");
        channelGrid.removeAllViews();
        String query=channelSearch.getText().toString().trim().toLowerCase(Locale.ROOT);
        ArrayList<Channel> matches=new ArrayList<>();
        for(Channel c:catalog){
            if(!c.name.toLowerCase(Locale.ROOT).contains(query))continue;
            if("favorite".equals(channelFilter)&&!c.favorite)continue;
            if("ready".equals(channelFilter)&&macroFor(c).length()==0)continue;
            matches.add(c);
        }
        if(matches.isEmpty()){
            TextView empty=text("没有找到频道。点击「添加体育频道」或批量导入频道名称。",13,SUB,false);
            add(channelGrid,empty,56);return;
        }
        String[] groups={GROUP_MAS,GROUP_DEPORTES};
        for(String group:groups){
            ArrayList<Channel> items=new ArrayList<>();
            for(Channel c:matches)if(group.equals(c.group))items.add(c);
            if(items.isEmpty())continue;
            TextView title=text(group+"  ("+items.size()+")",15,WHITE,true);
            addGap(channelGrid,12);add(channelGrid,title,34);
            for(int i=0;i<items.size();i+=2){
                final Channel left=items.get(i);
                Button a=channelButton(left);
                if(i+1<items.size()){
                    final Channel right=items.get(i+1);
                    Button b=channelButton(right);two(channelGrid,a,b,83);
                }else{
                    LinearLayout row=horizontal();
                    addWeighted(row,a,1);addWeighted(row,new View(this),1);
                    add(channelGrid,row,83);
                }
                addGap(channelGrid,7);
            }
        }
    }
    private Button channelButton(Channel c){
        boolean active=macroFor(c).length()>0;
        Button b=button((c.favorite?"★ ":"")+c.name+(active?"\n▶ 一键切台":"\n长按设置"),active?TILE:Color.rgb(38,48,65),true);
        b.setTextSize(13);
        b.setOnClickListener(v->channelTap(c));
        b.setOnLongClickListener(v->{editChannel(c);return true;});
        return b;
    }
    private void channelTap(Channel channel){
        if(recording!=null){toast("请先保存或取消当前录制");return;}
        JSONArray macro=macroFor(channel);
        if(macro.length()==0){editChannel(channel);return;}
        if(!requireConnected())return;
        if(playing){toast("正在执行其他频道操作");return;}
        playing=true;
        show("正在切换："+channel.name);
        work.execute(()->{
            try{
                for(int i=0;i<macro.length();i++){
                    JSONObject step=macro.getJSONObject(i);
                    String type=step.getString("t");
                    if("app".equals(type)){
                        remote.launch(step.getString("v"));Thread.sleep(4000);
                    }else if("key".equals(type)){
                        remote.press(step.getInt("v"));Thread.sleep(420);
                    }else if("wait".equals(type)){
                        Thread.sleep(Math.min(15000,step.getInt("v")));
                    }
                }
                show("已发送频道操作："+channel.name+"（请确认电视画面）");
            }catch(Exception e){error(e);}
            finally{playing=false;}
        });
    }
    private void editChannel(Channel channel){
        if(recording!=null){toast("正在录制："+recording.name);return;}
        String[] choices={"录制/重新录制切台步骤", channel.favorite?"取消收藏":"★ 加入收藏",
            "重命名频道","切换频道分类","清除切台录制","从频道库删除"};
        new AlertDialog.Builder(this).setTitle(channel.name).setItems(choices,(dialog,index)->{
            if(index==0){
                if(!requireConnected())return;
                recording=channel;recorded=new JSONArray();
                recordArea.setVisibility(View.VISIBLE);
                recordLabel.setText("正在录制："+recording.name+"（0 步）");
                toast("请先点「打开 TedeAr」，再用遥控按键找到频道");
            }else if(index==1){
                channel.favorite=!channel.favorite;saveChannels();refreshChannelButtons();
            }else if(index==2){
                EditText input=input("频道名称",channel.name);
                new AlertDialog.Builder(this).setTitle("重命名频道").setView(input)
                  .setPositiveButton("保存",(d,w)->{
                    String name=input.getText().toString().trim();
                    if(name.isEmpty()||name.length()>100||(!channel.name.equalsIgnoreCase(name)&&hasChannel(name))){toast("名称无效或已有同名频道");return;}
                    channel.name=name;saveChannels();refreshChannelButtons();
                  }).setNegativeButton("取消",null).show();
            }else if(index==3){
                String[] groups={GROUP_DEPORTES,GROUP_MAS};
                new AlertDialog.Builder(this).setTitle("选择分类").setItems(groups,(d,w)->{
                    channel.group=groups[w];saveChannels();refreshChannelButtons();
                }).show();
            }else if(index==4){
                new AlertDialog.Builder(this).setMessage("清除 "+channel.name+" 的操作记录？")
                    .setPositiveButton("清除",(d,w)->{
                        prefs.edit().remove("macro:"+channel.id).apply();refreshChannelButtons();
                    }).setNegativeButton("取消",null).show();
            }else if(index==5){
                new AlertDialog.Builder(this).setMessage("删除 "+channel.name+" 及其录制步骤？")
                    .setPositiveButton("删除",(d,w)->{
                        prefs.edit().remove("macro:"+channel.id).apply();catalog.remove(channel);
                        saveChannels();refreshChannelButtons();
                    }).setNegativeButton("取消",null).show();
            }
        }).show();
    }
    private void recordStep(String type,Object value){
        if(recording==null)return;
        try{
            JSONObject object=new JSONObject().put("t",type).put("v",value);
            if(recorded.length()>=150){toast("每个频道最多录制150个步骤");return;}
            recorded.put(object);
            recordLabel.setText("正在录制："+recording.name+"（"+recorded.length()+" 步）");
        }catch(Exception e){error(e);}
    }
    private void insertWait(int milliseconds){
        if(recording==null){toast("先长按一个频道开始录制");return;}
        recordStep("wait",milliseconds);
        toast("已经加入等待"+(milliseconds/1000)+"秒步骤");
    }
    private void saveRecording(){
        if(recording==null)return;
        if(recorded.length()==0){toast("没有录制任何步骤");return;}
        prefs.edit().putString("macro:"+recording.id,recorded.toString()).apply();
        toast("已保存 "+recording.name+" 的 "+recorded.length()+" 个操作步骤");
        resetRecording();refreshChannelButtons();
    }
    private void cancelRecording(){if(recording!=null){toast("已取消录制");resetRecording();}}
    private void resetRecording(){recording=null;recorded=new JSONArray();recordArea.setVisibility(View.GONE);}

    @Override public void status(String value){show(value);}
    @Override public void pairingCodeReady(){show("电视已显示配对码，请输入后点击确认配对码");}
    @Override public void pairingSucceeded(){show("配对成功，正在连接遥控…");}
    @Override public void connected(){show("● 已连接 Google TV · 可以遥控和录制频道");}
    @Override public void disconnected(String reason){show("● "+reason+" · 点击连接电视重试");}
    @Override protected void onDestroy(){
        stopDiscovery();remote.close();work.shutdownNow();super.onDestroy();
    }
}
