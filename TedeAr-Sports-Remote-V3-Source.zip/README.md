# TedeAr Sports Remote V3.0 — 全体育频道预置版

仅在 Android 手机上安装，控制同一局域网内已安装 TedeAr 的 Google TV。本源码不含视频源、第三方流媒体内容或账户信息。

## 已确认频道

来自用户上传的连续截图：**56 个不重复的体育频道**（MAS DEPORTES 3、DEPORTES 53）。其中新增截图包含 LPFPLAY 3–15、NBA、PX SPORTS、Rally TV、REAL MADRID TV、Red Bull TV、SHOWSPORT、SKY DAZN F1、TUDN、TyC Internacional、TyC Sports。

### MAS DEPORTES Y ALGO MAS（3 个）
- deporte 1
- deporte 2
- deporte 3

### DEPORTES（53 个）
- ESPN PREMIUM
- ESPN PREMIUM OP2
- TNT SPORTS
- AMERICA SPORTS
- BEIN SPORTS XTRA
- BEIN SPORTS XTRA Ñ
- DAZN COMBAT
- DAZN F1 OP1
- DAZN F1 OP2
- DEPORTV
- ESPN
- ESPN 2
- ESPN 3
- ESPN 4
- ESPN 5
- ESPN 6
- ESPN 7
- EVENTOS EXCLUSIVOS 116
- EVENTOS EXCLUSIVOS 117
- FOX SPORTS HD
- FOX SPORTS 2 HD
- FOX SPORTS 3 HD
- FOX SPORTS PREMIUM
- GARAGE TV
- GOLF CHANNEL
- Identidad 1
- IDENTIDAD 4
- san martin-cipoletti
- LPFPLAY
- LPFPLAY 2
- LPFPLAY 3
- LPFPLAY 4
- LPFPLAY 5
- LPFPLAY 6
- LPFPLAY 7
- LPFPLAY 8
- LPFPLAY 9
- LPFPLAY 10
- LPFPLAY 11
- LPFPLAY 12
- LPFPLAY 13
- LPFPLAY 14
- LPFPLAY 15
- NBA
- PX SPORTS
- Rally TV
- REAL MADRID TV
- Red Bull TV
- SHOWSPORT
- SKY DAZN F1
- TUDN
- TYC INTERNACIONAL
- TYC SPORTS

频道为截图文字预置，**不保证这是 TedeAr 服务端实时存在的全部频道**；后续新频道仍可自行添加或批量导入，最多 500 个。原列表的 LPFPLAY 13 在新截图中重复出现，只保存一个。截断标签按图标和常见名称补全；名称如有不一致，可长按改名。

## 遥控 / 切台

- Wi-Fi 局域网遥控，首次连接需电视显示配对码（Android TV Remote Service v2）。
- 一键发送启动 TedeAr 请求；能否被当前 Google TV 的遥控服务执行，需要实机验证。
- **无法从 APK 证明存在可调用的频道直达接口。** 因此不能承诺安装后点频道名便能立即播放。
- 首次长按频道选择「录制/重新录制切台步骤」→ 用手机遥控进入对应频道 → 保存录制。此后点同一频道，自动重放录制的步骤。各频道需要单独录制，TedeAr 界面变化时录制可能失效。
- 可以搜索、收藏、筛选已录制、编辑/删除频道。已有 V2 频道库在应用数据可保留的情况下自动合并新增频道，尽量保留旧录制。

## GitHub Actions 编译（无需解压 ZIP）

1. 在 https://github.com/new 创建仓库，推荐仓库名 `TedeAr-Sports-Remote-V3`。
2. 把 `TedeAr-Sports-Remote-V3-Source.zip` 作为 **完整 ZIP 文件** 上传至仓库根目录；不要解压。
3. 建立仓库路径 `.github/workflows/android.yml`，把随附 `GITHUB-ACTIONS-V3-直接粘贴.txt` 全部粘贴进去并提交。
4. 前往仓库 `Actions` → `Build TedeAr Sports Remote APK` → `Run workflow`。
5. 编译成功后，打开 Artifacts → `TedeAr-Sports-Remote-V3-APK`，下载并解压得到 `app-debug.apk`。

若改用解压后上传源码，仓库目录内需直接有 `app/`, `build.gradle`, `.github/workflows/android.yml` 等文件。

**注意**：GitHub Actions 生成的 debug APK 每个新环境可能用不同签名。如果你的手机已安装其他构建的旧版，升级时可能提示签名不一致，需用同一签名重新构建，或卸载旧版再安装（卸载会丢失未备份的频道设置和录制）。

构建环境：JDK 17、Gradle 8.10.2、AGP 8.7.3、Android API 35。当前环境缺少 Android SDK，已做离线代码与 ZIP 结构核验，未实机验证或在此构建 APK。
